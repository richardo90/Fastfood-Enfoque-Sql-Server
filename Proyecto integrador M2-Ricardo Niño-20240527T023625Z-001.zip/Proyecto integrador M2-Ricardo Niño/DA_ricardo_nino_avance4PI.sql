USE Fastfood_BD

--Listar todos los productos y sus categor�as
--Pregunta: �C�mo puedo obtener una lista de todos los productos junto con sus categor�as?
SELECT T1.Nombre AS Producto, T2.Nombre AS Categoria
FROM Productos AS T1
 INNER JOIN Categorias AS T2
   ON T1.CategoriaId=T2.CategoriaID
;
--Obtener empleados y su sucursal asignada
--Pregunta: �C�mo puedo saber a qu� sucursal est� asignado cada empleado?

SELECT T1.EmpleadoID, T1.Nombre, T1.Departamento ,T2.Nombre 
        FROM Empleados AS T1
         INNER JOIN Sucursales AS T2
         ON T1.SucursalID= T2.SucursalID
		 ;

--Identificar productos sin categor�a asignada
--Pregunta: �Existen productos que no tienen una categor�a asignada?

SELECT * FROM Productos AS T1
     LEFT JOIN Categorias AS T2
	 ON T1.CategoriaId=T2.CategoriaID
	 WHERE T2.CategoriaID IS NULL
	 ;


--Detalle completo de �rdenes
--Pregunta: �C�mo puedo obtener un detalle completo de las �rdenes, incluyendo cliente, empleado que tom� la orden, y el mensajero que la entreg�?

SELECT T1.*, T2.Nombre AS Cliente, T3.Nombre AS Empleado , T4.Nombre AS Mensajero 
FROM Ordenes AS T1
INNER JOIN  Clientes AS T2
ON T1.ClienteID=T2.ClienteID
INNER JOIN Empleados AS T3
ON T1.EmpleadoID=T3.EmpleadoID
INNER JOIN Mensajeros AS T4
ON T1.MensajeroID= T4.MensajeroID
;
       
--Productos vendidos por sucursal
-- �Cu�ntos productos de cada tipo se han vendido en cada sucursal?


SELECT T5.Nombre AS Sucursal, T4.Nombre AS Categoria ,SUM(Cantidad) AS Cantidaddearticulosvendidos
FROM Ordenes AS T1
INNER JOIN DetalleOrdenes AS T2
   ON T1.OrdenID=T2.OrdenID
   INNER JOIN Productos AS T3
   ON T2.ProductoID= T3.ProductoId
   INNER JOIN Categorias AS T4
   ON T3.CategoriaId=T4.CategoriaID
   INNER JOIN Sucursales AS T5
   ON T1.SucursalID = T5.SucursalID
   
GROUP BY T5.NOMBRE, T4.NOMBRE
;



--Eficiencia de los mensajeros: 
--�Cu�l es el tiempo promedio desde el despacho hasta la entrega de los pedidos por los mensajeros?

SELECT AVG(DATEDIFF(MINUTE,FechaDespacho,FechaEntrega)) AS PROMEDIO 
FROM Ordenes

--An�lisis de Ventas por Origen de Orden: 
--�Qu� canal de ventas genera m�s ingresos?

SELECT T2.Descripcion, SUM(TotalCompra) AS Totalventas 
   FROM Ordenes AS T1
   INNER JOIN OrigenesOrden AS T2
   ON T1.OrigenID=T2.OrigenID
   GROUP BY T2.Descripcion
   ORDER BY Totalventas DESC;


--Productividad de los Empleados:
--�Cu�l es el volumen de ventas promedio gestionado por empleado?
SELECT T2. NOMBRE, COUNT(OrdenID) AS Promedioventas 
FROM Ordenes AS T1
INNER JOIN Empleados AS T2
ON T1.EmpleadoID= T2.EmpleadoID
GROUP BY T2.Nombre;

--An�lisis de Demanda por Horario y D�a:
--�C�mo var�a la demanda de productos a lo largo del d�a? 
--NOTA: Esta consulta no puede ser implementada sin una definici�n clara del horario (ma�ana, tarde, noche) en la base de datos existente. Asumiremos que HorarioVenta refleja esta informaci�n correctamente.

SELECT HorarioVenta,SUM(Cantidad) AS Demandaproductos
    FROM Ordenes AS T1
    INNER JOIN DetalleOrdenes AS T2
    ON T1.OrdenID= T2.OrdenID
	GROUP BY HorarioVenta;

--Comparaci�n de Ventas Mensuales: �C�mo se comparan las ventas mensuales de este a�o con el a�o anterior?

SELECT FORMAT (FechaOrdenTomada, 'yyyy-MM') AS  Periodo,SUM (TotalCompra) AS TotalVentas
FROM Ordenes
GROUP BY FechaOrdenTomada; 


--An�lisis de Fidelidad del Cliente: �Qu� porcentaje de clientes son recurrentes versus nuevos clientes cada mes? NOTA: La consulta se enfocar�a en la frecuencia de �rdenes por cliente para inferir la fidelidad.

SELECT ClienteID, COUNT(OrdenID) AS Numerodeordenes FROM Ordenes
GROUP BY ClienteID;

--No hay informaci�n historica para obtener la fidelidad del cliente.
--Solo se puede observar que los clientes realizaron 1 orden.

