USE Fastfood_BD

--Total de ventas globales
--Pregunta: �Cu�l es el total de ventas (TotalCompra) a nivel global?

SELECT SUM(TotalCompra) AS VentasGlobales
FROM Ordenes


--Promedio de precios de productos por categor�a
--Pregunta: �Cu�l es el precio promedio de los productos dentro de cada categor�a?

SELECT CategoriaID, AVG(Precio) AS Preciopromedio
FROM Productos
GROUP BY CategoriaID


--Orden m�nima y m�xima por sucursal
--Pregunta: �Cu�l es el valor de la orden m�nima y m�xima por cada sucursal?

SELECT SucursalID,
       MIN(TotalCompra) AS Ordenminima,
       MAX(TotalCompra) AS Ordenmaxima
FROM   Ordenes
GROUP BY SucursalID;



--Mayor n�mero de kil�metros recorridos para entrega
--Pregunta: �Cu�l es el mayor n�mero de kil�metros recorridos para una entrega?

SELECT MAX (KilometrosRecorrer) AS MAXKM 
FROM Ordenes



--Promedio de cantidad de productos por orden
--Pregunta: �Cu�l es la cantidad promedio de productos por orden?


SELECT AVG(Cantidad) AS Promedioproductospororden
FROM DetalleOrdenes


--Total de ventas por tipo de pago
--Pregunta: �Cu�l es el total de ventas por cada tipo de pago?


SELECT TipoPagoID, SUM (TotalCompra) AS Totalventas
FROM Ordenes
GROUP BY TipoPagoID

--Sucursal con la venta promedio m�s alta
--Pregunta: �Cu�l sucursal tiene la venta promedio m�s alta?

SELECT TOP 1 SucursalID , AVG (TotalCompra) AS Promediocompra
FROM Ordenes
GROUP BY SucursalID 
ORDER BY Promediocompra DESC --Criterio 


--Sucursal con la mayor cantidad de ventas por encima de un umbral
--Pregunta: �Cu�les son las sucursales que han generado ventas por orden por encima de $100, y c�mo se comparan en t�rminos del total de ventas?

SELECT SucursalID,	SUM (TotalCompra) AS TotalCompra, COUNT (OrdenID) AS Cantidaddeordenes
FROM Ordenes
GROUP BY SucursalID
HAVING SUM (TotalCompra)>100;

--Comparaci�n de ventas promedio antes y despu�s de una fecha espec�fica
--Pregunta: �C�mo se comparan las ventas promedio antes y despu�s del 1 de julio de 2023?

SELECT AVG(TotalCompra) AS PromedioVenta , 'Promedio ventas antes de Julio 2023' AS Comentario
FROM Ordenes
WHERE FechaOrdenTomada < '2023-07-01'

SELECT AVG(TotalCompra) AS PromedioVenta , 'Promedio ventas despues de Julio 2023' AS Comentario
FROM Ordenes
WHERE FechaOrdenTomada > '2023-07-01'

--An�lisis de actividad de ventas por horario
--Pregunta: �Durante qu� horario del d�a (ma�ana, tarde, noche) se registra la mayor cantidad de ventas, cu�l es el valor promedio de estas ventas, y cu�l ha sido la venta m�xima alcanzada?

SELECT HorarioVenta , 
       COUNT(OrdenID) AS Numerodeventas,
	   AVG(TotalCompra)AS Promedioventas,
	   MAX(TotalCompra)AS VentaMaxima
FROM Ordenes
GROUP BY HorarioVenta
Order BY VentaMaxima;

