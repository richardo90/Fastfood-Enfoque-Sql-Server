-- Posicionandome sobre la BD
USE fastfood_BD;


--Creaci�n de tablas
CREATE TABLE Productos (
    ProductoID INT PRIMARY KEY IDENTITY,
	Nombre VARCHAR (255) NOT NULL,
	CategoriaID INT,--Referencia a la Clave Primaria de Categoria		 
	Precio DECIMAL (10,2) NOT NULL);

CREATE TABLE Categorias (
    CategoriaID INT PRIMARY KEY IDENTITY,
	Nombre VARCHAR(255) NOT NULL );

DROP TABLE Cateogrias
DROP TABLE Categorias

CREATE TABLE Categorias (
    CategoriaID INT PRIMARY KEY IDENTITY,
	Nombre VARCHAR(255) NOT NULL );

CREATE TABLE Sucursales (
    SucursalID INT PRIMARY KEY IDENTITY,
	Nombre VARCHAR (255) NOT NULL,
	Direccion VARCHAR (255) );

CREATE TABLE Empleados (
    EmpleadoID INT PRIMARY KEY IDENTITY,
	Nombre VARCHAR(255) NOT NULL,
	Posicion VARCHAR (255),
	Departamento VARCHAR (255),
	SucursalID INT) ; 

--Generar un campo llamado Rol en la tabla Empleados
ALTER TABLE Empleados
ADD Rol VARCHAR (255);

CREATE TABLE Clientes (
    ClienteID INT PRIMARY KEY IDENTITY ,
	Nombre VARCHAR (255) NOT NULL,
	Direccion VARCHAR (255));

CREATE TABLE OrigenesOrden (
    OrigenID INT PRIMARY KEY IDENTITY,
	Descripcion VARCHAR (255) NOT NULL );

CREATE TABLE TiposPago(
    TipoPagoID INT PRIMARY KEY IDENTITY ,
	Descripcion VARCHAR(255) NOT NULL );

CREATE TABLE Mensajeros (
    MensajeroID INT PRIMARY KEY IDENTITY,
	Nombre VARCHAR (255) NOT NULL,
	EsExterno BIT)-- Genero un ALTER para el NOT NULL;

ALTER TABLE Mensajeros 
ALTER COLUMN  EsExterno BIT NOT NULL;

CREATE TABLE Ordenes (
    Nombre INT PRIMARY KEY IDENTITY,
	ClienteID INT,
	EmpleadoID INT, -- Vendedor que tomo la orden 
	SucursalID INT, 
	MensajeroID INT, -- Se asume que puede ser empleado o un mensajero externo
	TipoPagoID INT,
	OrigenID INT , --En linea,presencial,tel�fono, drive thru
	HorarioVenta VARCHAR (50) , --Ma�ana,tarde,noche
	TotalCompra DECIMAL (10,2),
	KilometrosRecorrer DECIMAL (10,2),-- En caso de entrega a domicilio
	FechaDespacho DATETIME,--Hora y fecha de entrega al repartidor
	FechaEntrega DATETIME, -- Hora y fecha de la orden de entrega
	FechaOrdenTomada DATETIME,-- En caso de drive thru o presencial
	FechaOrdenLista DATETIME,);

DROP TABLE Ordenes

CREATE TABLE Ordenes (
    OrdenID INT PRIMARY KEY IDENTITY,
	ClienteID INT,
	EmpleadoID INT, -- Vendedor que tomo la orden 
	SucursalID INT, 
	MensajeroID INT, -- Se asume que puede ser empleado o un mensajero externo
	TipoPagoID INT,
	OrigenID INT , --En linea,presencial,tel�fono, drive thru
	HorarioVenta VARCHAR (50) , --Ma�ana,tarde,noche
	TotalCompra DECIMAL (10,2),
	KilometrosRecorrer DECIMAL (10,2),-- En caso de entrega a domicilio
	FechaDespacho DATETIME,--Hora y fecha de entrega al repartidor
	FechaEntrega DATETIME, -- Hora y fecha de la orden de entrega
	FechaOrdenTomada DATETIME,-- En caso de drive thru o presencial
	FechaOrdenLista DATETIME,);


CREATE TABLE DetalleOrdenes (
    OrdenID INT,
	ProductoID INT,
	Cantidad INT,
	Precio DECIMAL (10,2),
	PRIMARY KEY (OrdenID, ProductoID));


----------------------------------Generar relaciones------------------------------------------------

--

ALTER TABLE Ordenes
ADD CONSTRAINT FK_Ordenes_Sucursales
FOREIGN KEY (SucursalID) REFERENCES Sucursales(SucursalID);

ALTER TABLE Ordenes
ADD CONSTRAINT FK_Ordenes_Empleados
FOREIGN KEY (EmpleadoID) REFERENCES Empleados(EmpleadoID);

ALTER TABLE Ordenes
ADD CONSTRAINT FK_Ordenes_Mensajeros
FOREIGN KEY (MensajeroID) REFERENCES Mensajeros(MensajeroID);

ALTER TABLE Ordenes
ADD CONSTRAINT FK_Ordenes_Clientes
FOREIGN KEY (ClienteID) REFERENCES Clientes(ClienteID);	

ALTER TABLE Ordenes
ADD CONSTRAINT FK_Ordenes_OrigenesOrden
FOREIGN KEY (OrigenID) REFERENCES OrigenesOrden(OrigenID);	

ALTER TABLE DetalleOrdenes
ADD CONSTRAINT FK_DetalleOrdenes_Ordenes
FOREIGN KEY (ProductoID) REFERENCES Productos(ProductoID);	

ALTER TABLE DetalleOrdenes
ADD CONSTRAINT FK_DetalleOrden_Orden
FOREIGN KEY (OrdenID) REFERENCES Ordenes(OrdenID);
	
ALTER TABLE Productos
ADD CONSTRAINT FK_Productos_Categoria
FOREIGN KEY (CategoriaID) REFERENCES Categorias(CategoriaID);

ALTER TABLE Ordenes
ADD CONSTRAINT FK_Ordenes_Tipospago
FOREIGN KEY (TipoPagoID) REFERENCES TiposPago(TipopagoID);
